import cv2
import numpy as np

cap = cv2.VideoCapture(0)

# Green laser HSV range
lower = np.array([35, 80, 100])
upper = np.array([90, 255, 255])

# Statue part coordinates
parts = {
    "Head": (640, 180),
    "Face": (640, 240),
    "Right Hand": (760, 390),
    "Left Hand": (520, 390),
    "Chest": (640, 420),
    "Base": (640, 650)
}

def explain(part):
    answers = {
        "Head": "This is the head portion of the statue.",
        "Face": "This is the face of the statue.",
        "Right Hand": "This is the right hand portion of the statue.",
        "Left Hand": "This is the left hand portion of the statue.",
        "Chest": "This is the chest portion of the statue.",
        "Base": "This is the base of the statue."
    }
    return answers.get(part, "Information is not available.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower, upper)

    contours, _ = cv2.findContours(
        mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    laser = None

    if contours:
        contour = max(contours, key=cv2.contourArea)

        if cv2.contourArea(contour) > 3:
            M = cv2.moments(contour)

            if M["m00"] != 0:
                x = int(M["m10"] / M["m00"])
                y = int(M["m01"] / M["m00"])
                laser = (x, y)

    selected = None

    if laser:
        x, y = laser
        cv2.circle(frame, (x, y), 10, (0, 0, 255), 2)

        for name, (px, py) in parts.items():
            if np.hypot(x - px, y - py) < 100:
                selected = name
                break

    for name, (x, y) in parts.items():
        cv2.putText(
            frame, name, (x, y),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5,
            (255, 255, 255), 1
        )

    if selected:
        cv2.putText(
            frame, f"Selected: {selected}", (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX, 0.8,
            (0, 255, 0), 2
        )

    cv2.imshow("Heritage Vision", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
